#!/usr/bin/env python3
"""
analyze_results.py - Analiza resultados de benchmarks MPI
Calcula speedup, eficiencia, y genera visualizaciones
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

# Configuración
RESULTS_FILE = "results/benchmarks.csv"
OUTPUT_DIR = "results"

def load_data():
    """Carga datos de benchmarks"""
    df = pd.read_csv(RESULTS_FILE)
    # Filtrar solo ejecuciones exitosas
    df = df[df['status'] == 'success'].copy()
    df['execution_time'] = pd.to_numeric(df['execution_time'])
    return df

def calculate_speedup(df):
    """Calcula speedup y eficiencia"""
    results = []
    
    for impl in df['implementation'].unique():
        impl_df = df[df['implementation'] == impl]
        
        for size in df['matrix_size'].unique():
            size_df = impl_df[impl_df['matrix_size'] == size]
            
            # Baseline: sequential con 1 proceso (o menor número de procesos)
            baseline_time = size_df[size_df['num_processes'] == size_df['num_processes'].min()]['execution_time'].values
            
            if len(baseline_time) == 0:
                continue
            baseline_time = baseline_time[0]
            
            for _, row in size_df.iterrows():
                procs = row['num_processes']
                time = row['execution_time']
                speedup = baseline_time / time
                efficiency = speedup / procs * 100
                
                results.append({
                    'implementation': impl,
                    'matrix_size': size,
                    'num_processes': procs,
                    'execution_time': time,
                    'speedup': speedup,
                    'efficiency': efficiency,
                    'baseline_time': baseline_time
                })
    
    return pd.DataFrame(results)

def plot_speedup(df, output_dir):
    """Gráfica de speedup vs procesos"""
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    sizes = sorted(df['matrix_size'].unique())
    
    for idx, size in enumerate(sizes):
        ax = axes[idx]
        size_df = df[df['matrix_size'] == size]
        
        for impl in df['implementation'].unique():
            impl_df = size_df[size_df['implementation'] == impl]
            if len(impl_df) > 0:
                ax.plot(impl_df['num_processes'], impl_df['speedup'], 
                       marker='o', label=impl, linewidth=2, markersize=8)
        
        # Línea ideal
        procs = sorted(df['num_processes'].unique())
        ax.plot(procs, procs, 'k--', label='Ideal', alpha=0.5)
        
        ax.set_xlabel('Number of Processes', fontsize=12)
        ax.set_ylabel('Speedup', fontsize=12)
        ax.set_title(f'Matrix Size: {size}x{size}', fontsize=14, fontweight='bold')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_xticks(procs)
    
    plt.tight_layout()
    plt.savefig(f"{output_dir}/speedup_comparison.png", dpi=300, bbox_inches='tight')
    print(f"Saved: {output_dir}/speedup_comparison.png")
    plt.close()

def plot_efficiency(df, output_dir):
    """Gráfica de eficiencia"""
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    sizes = sorted(df['matrix_size'].unique())
    
    for idx, size in enumerate(sizes):
        ax = axes[idx]
        size_df = df[df['matrix_size'] == size]
        
        for impl in df['implementation'].unique():
            impl_df = size_df[size_df['implementation'] == impl]
            if len(impl_df) > 0:
                ax.plot(impl_df['num_processes'], impl_df['efficiency'], 
                       marker='s', label=impl, linewidth=2, markersize=8)
        
        ax.axhline(y=100, color='k', linestyle='--', alpha=0.5, label='Ideal (100%)')
        ax.set_xlabel('Number of Processes', fontsize=12)
        ax.set_ylabel('Efficiency (%)', fontsize=12)
        ax.set_title(f'Matrix Size: {size}x{size}', fontsize=14, fontweight='bold')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_ylim(0, 120)
        procs = sorted(df['num_processes'].unique())
        ax.set_xticks(procs)
    
    plt.tight_layout()
    plt.savefig(f"{output_dir}/efficiency_comparison.png", dpi=300, bbox_inches='tight')
    print(f"Saved: {output_dir}/efficiency_comparison.png")
    plt.close()

def plot_execution_times(df, output_dir):
    """Gráfica de tiempos de ejecución"""
    fig, ax = plt.subplots(figsize=(12, 6))
    
    # Crear tabla pivote
    implementations = df['implementation'].unique()
    x = np.arange(len(df['matrix_size'].unique()))
    width = 0.15
    
    for idx, impl in enumerate(implementations):
        impl_df = df[df['implementation'] == impl]
        
        for proc_count in sorted(df['num_processes'].unique()):
            proc_df = impl_df[impl_df['num_processes'] == proc_count]
            if len(proc_df) > 0:
                times = []
                for size in sorted(df['matrix_size'].unique()):
                    time_val = proc_df[proc_df['matrix_size'] == size]['execution_time'].values
                    times.append(time_val[0] if len(time_val) > 0 else 0)
                
                offset = (idx - len(implementations)/2) * width
                ax.bar(x + offset, times, width, 
                      label=f'{impl} ({proc_count}p)', alpha=0.8)
    
    ax.set_xlabel('Matrix Size', fontsize=12)
    ax.set_ylabel('Execution Time (seconds)', fontsize=12)
    ax.set_title('Execution Time Comparison', fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels([f'{s}x{s}' for s in sorted(df['matrix_size'].unique())])
    ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    ax.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    plt.savefig(f"{output_dir}/execution_times.png", dpi=300, bbox_inches='tight')
    print(f"Saved: {output_dir}/execution_times.png")
    plt.close()

def plot_heatmap_speedup(df, output_dir):
    """Heatmap de speedup"""
    fig, axes = plt.subplots(2, 2, figsize=(14, 12))
    axes = axes.flatten()
    
    implementations = sorted(df['implementation'].unique())
    
    for idx, impl in enumerate(implementations):
        ax = axes[idx]
        impl_df = df[df['implementation'] == impl]
        
        # Crear pivote para heatmap
        pivot = impl_df.pivot_table(
            values='speedup',
            index='matrix_size',
            columns='num_processes',
            aggfunc='mean'
        )
        
        sns.heatmap(pivot, annot=True, fmt='.2f', cmap='RdYlGn', 
                   ax=ax, cbar_kws={'label': 'Speedup'},
                   vmin=0, vmax=6)
        ax.set_title(f'{impl.capitalize()} - Speedup', fontsize=12, fontweight='bold')
        ax.set_xlabel('Number of Processes')
        ax.set_ylabel('Matrix Size')
    
    plt.tight_layout()
    plt.savefig(f"{output_dir}/speedup_heatmap.png", dpi=300, bbox_inches='tight')
    print(f"Saved: {output_dir}/speedup_heatmap.png")
    plt.close()

def generate_summary_report(df, output_file):
    """Genera reporte de texto con estadísticas"""
    with open(output_file, 'w') as f:
        f.write("=" * 80 + "\n")
        f.write("MPI MATRIX MULTIPLICATION - BENCHMARK SUMMARY\n")
        f.write("=" * 80 + "\n\n")
        
        f.write("OVERALL STATISTICS\n")
        f.write("-" * 80 + "\n")
        f.write(f"Total successful runs: {len(df)}\n")
        f.write(f"Implementations tested: {', '.join(df['implementation'].unique())}\n")
        f.write(f"Matrix sizes: {', '.join(map(str, sorted(df['matrix_size'].unique())))}\n")
        f.write(f"Process counts: {', '.join(map(str, sorted(df['num_processes'].unique())))}\n\n")
        
        # Best results
        f.write("BEST SPEEDUP BY IMPLEMENTATION\n")
        f.write("-" * 80 + "\n")
        for impl in sorted(df['implementation'].unique()):
            impl_df = df[df['implementation'] == impl]
            best = impl_df.loc[impl_df['speedup'].idxmax()]
            f.write(f"{impl.capitalize():20s}: {best['speedup']:.2f}x ")
            f.write(f"(size={int(best['matrix_size'])}, procs={int(best['num_processes'])})\n")
        
        f.write("\n")
        f.write("BEST EFFICIENCY BY IMPLEMENTATION\n")
        f.write("-" * 80 + "\n")
        for impl in sorted(df['implementation'].unique()):
            impl_df = df[df['implementation'] == impl]
            best = impl_df.loc[impl_df['efficiency'].idxmax()]
            f.write(f"{impl.capitalize():20s}: {best['efficiency']:.1f}% ")
            f.write(f"(size={int(best['matrix_size'])}, procs={int(best['num_processes'])})\n")
        
        f.write("\n")
        f.write("DETAILED RESULTS BY MATRIX SIZE\n")
        f.write("-" * 80 + "\n")
        
        for size in sorted(df['matrix_size'].unique()):
            f.write(f"\n{size}x{size} Matrix:\n")
            size_df = df[df['matrix_size'] == size]
            
            for impl in sorted(df['implementation'].unique()):
                impl_df = size_df[size_df['implementation'] == impl]
                if len(impl_df) > 0:
                    f.write(f"  {impl.capitalize()}\n")
                    for _, row in impl_df.sort_values('num_processes').iterrows():
                        f.write(f"    {int(row['num_processes'])} procs: ")
                        f.write(f"{row['execution_time']:8.4f}s  ")
                        f.write(f"Speedup: {row['speedup']:5.2f}x  ")
                        f.write(f"Efficiency: {row['efficiency']:5.1f}%\n")
        
        f.write("\n")
        f.write("=" * 80 + "\n")
    
    print(f"Saved: {output_file}")

def main():
    print("=== MPI Benchmark Analysis ===\n")
    
    # Verificar archivo de resultados
    if not Path(RESULTS_FILE).exists():
        print(f"Error: {RESULTS_FILE} not found")
        print("Run ./scripts/run_benchmarks.sh first")
        return
    
    # Cargar y procesar datos
    print("Loading data...")
    df_raw = load_data()
    
    if len(df_raw) == 0:
        print("No successful benchmark results found!")
        return
    
    print(f"Loaded {len(df_raw)} successful results")
    
    print("\nCalculating speedup and efficiency...")
    df = calculate_speedup(df_raw)
    
    # Guardar resultados procesados
    processed_file = f"{OUTPUT_DIR}/processed_results.csv"
    df.to_csv(processed_file, index=False)
    print(f"Saved processed data: {processed_file}")
    
    # Generar visualizaciones
    print("\nGenerating plots...")
    plot_speedup(df, OUTPUT_DIR)
    plot_efficiency(df, OUTPUT_DIR)
    plot_execution_times(df, OUTPUT_DIR)
    plot_heatmap_speedup(df, OUTPUT_DIR)
    
    # Generar reporte
    print("\nGenerating summary report...")
    generate_summary_report(df, f"{OUTPUT_DIR}/summary_report.txt")
    
    print("\n=== Analysis Complete ===")
    print(f"\nResults saved in: {OUTPUT_DIR}/")
    print("  - processed_results.csv")
    print("  - summary_report.txt")
    print("  - speedup_comparison.png")
    print("  - efficiency_comparison.png")
    print("  - execution_times.png")
    print("  - speedup_heatmap.png")

if __name__ == "__main__":
    main()
